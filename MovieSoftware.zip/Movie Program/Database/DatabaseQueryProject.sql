USE MovieWorld;

CREATE TABLE Genre ( 

	GenreId INT IDENTITY(1,1) PRIMARY KEY,
	GenreName VARCHAR(50)

);

CREATE TABLE Movie (

	MovieId int IDENTITY(1,1) PRIMARY KEY ,
	MovieName VARCHAR(50),
	Description VARCHAR(500),
	GenreId INT FOREIGN KEY REFERENCES Genre(GenreId)
	
);

CREATE TABLE Users (

	UsersId INT PRIMARY KEY,
	Username VARCHAR(50),
	Password VARCHAR(50)

);


INSERT INTO Genre (GenreName) VALUES ('Action');
INSERT INTO Genre (GenreName) VALUES ('Comedy');
INSERT INTO Genre (GenreName) VALUES ('Drama');

INSERT INTO Movie ( MovieName, Description) VALUES ('Avengers Endgame', 'After the devastating events of Avengers: Infinity War (2018), the universe is in ruins. With the help of remaining allies, the Avengers assemble once more in order to reverse Thanos'' actions and restore balance to the universe.');
INSERT INTO Movie ( MovieName, Description) VALUES ('Hot Rod', 'Hot Rod is a 2007 American comedy film directed by Akiva Schaffer (in his directorial debut) and written by Pam Brady. The film stars Andy Samberg as amateur stuntman Rod Kimble, whose stepfather, Frank (Ian McShane), continuously mocks and disrespects him. When Frank becomes ill, Rod raises money for his heart operation by executing his largest stunt yet.');
INSERT INTO Movie ( MovieName, Description) VALUES ('Rocky', 'Rocky is a 1976 American sports drama film directed by John G. Avildsen and written by and starring Sylvester Stallone. It is the first installment in the Rocky franchise and also stars Talia Shire, Burt Young, Carl Weathers, and Burgess Meredith. In the film, Rocky Balboa, a poor small-time club fighter and loanshark debt collector, gets an unlikely shot at the world heavyweight championship held by Apollo Creed.');

INSERT INTO Users (UsersId, Username, Password) VALUES(1, 'Juan', 'admin');
INSERT INTO Users (UsersId, Username, Password) VALUES(2, 'Lanouska', 'admin');
INSERT INTO Users (UsersId, Username, Password) VALUES(3, 'Peter', 'admin');
